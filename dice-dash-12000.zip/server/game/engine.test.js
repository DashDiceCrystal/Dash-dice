'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const E = require('./engine');

// Scripted dice: values are consumed in order (roll-off first, then turns).
function scriptedGame(seq, playerIds = ['a', 'b'], options = {}) {
  let i = 0;
  const rng = () => {
    if (i >= seq.length) throw new Error('ran out of scripted dice');
    return seq[i++];
  };
  return E.createGame(playerIds, { ...options, rng });
}

function rollOffFirst(g) {
  return E.doRollOff(g); // consumes dice from the script
}

// --- scoring primitives -----------------------------------------------------

test('faceTotal matches the tables', () => {
  assert.equal(E.faceTotal(4, 3), 400);
  assert.equal(E.faceTotal(4, 4), 1600);
  assert.equal(E.faceTotal(4, 5), 2000);
  assert.equal(E.faceTotal(1, 3), 1000);
  assert.equal(E.faceTotal(1, 4), 4000);
  assert.equal(E.faceTotal(1, 5), 5000);
  assert.equal(E.faceTotal(1, 1), 100);
  assert.equal(E.faceTotal(5, 2), 100);
  assert.equal(E.faceTotal(3, 2), 0);
});

test('roll-off picks highest, ties re-roll', () => {
  const g = scriptedGame([4, 4, 6, 2]); // tie, then a wins
  const res = rollOffFirst(g);
  assert.equal(res.rounds.length, 2);
  assert.equal(res.first, 0);
  assert.equal(g.current, 0);
  assert.equal(g.phase, 'play');
});

// --- basic turn flow --------------------------------------------------------

test('three of a kind activates and scores', () => {
  const g = scriptedGame([6, 1, 4, 4, 4, 2, 3, 6]);
  rollOffFirst(g);
  const r = E.roll(g);
  assert.deepEqual(r.dice, [4, 4, 4, 2, 3, 6]);
  const k = E.keep(g, [0, 1, 2]);
  assert.equal(k.delta, 400);
  assert.equal(g.turn.turnTotal, 400);
  assert.equal(g.turn.activated[4], true);
  assert.equal(g.turn.diceRemaining, 3);
  assert.equal(g.turn.awaiting, 'decision');
});

test('single 1s and 5s score', () => {
  const g = scriptedGame([6, 1, 1, 5, 2, 3, 4, 6]);
  rollOffFirst(g);
  E.roll(g);
  const k = E.keep(g, [0, 1]);
  assert.equal(k.delta, 150);
  assert.equal(g.turn.turnTotal, 150);
});

test('two single 1s then a third completes 1000 total (not 1200)', () => {
  const g = scriptedGame([6, 1, 1, 1, 2, 3, 4, 6, 1, 2, 3, 6]);
  rollOffFirst(g);
  E.roll(g);
  E.keep(g, [0, 1]); // 200
  assert.equal(g.turn.turnTotal, 200);
  E.roll(g); // 4 dice
  const k = E.keep(g, [0]); // third 1 -> total for 1s becomes 1000
  assert.equal(k.delta, 800);
  assert.equal(g.turn.turnTotal, 1000);
  assert.equal(g.turn.activated[1], true);
});

test('activated face: fourth die scores table marginal', () => {
  const g = scriptedGame([6, 1, 4, 4, 4, 2, 3, 6, 4, 2, 3]);
  rollOffFirst(g);
  E.roll(g);
  E.keep(g, [0, 1, 2]); // 400
  E.roll(g); // 3 dice: 4,2,3
  const k = E.keep(g, [0]); // fourth 4 -> 1600 total
  assert.equal(k.delta, 1200);
  assert.equal(g.turn.turnTotal, 1600);
});

test('four of a kind kept at once scores the table value', () => {
  const g = scriptedGame([6, 1, 2, 2, 2, 2, 3, 6]);
  rollOffFirst(g);
  E.roll(g);
  const k = E.keep(g, [0, 1, 2, 3]);
  assert.equal(k.delta, 800);
  assert.equal(g.turn.activated[2], true);
});

test('keeping a non-scoring die throws', () => {
  const g = scriptedGame([6, 1, 1, 2, 2, 3, 4, 6]);
  rollOffFirst(g);
  E.roll(g);
  assert.throws(() => E.keep(g, [1]), /not scoring/);
});

test('must keep at least one die', () => {
  const g = scriptedGame([6, 1, 1, 5, 2, 3, 4, 6]);
  rollOffFirst(g);
  E.roll(g);
  assert.throws(() => E.keep(g, []), /at least one/);
});

// --- combos -----------------------------------------------------------------

test('straight scores 1500 and triggers hot dice', () => {
  const g = scriptedGame([6, 1, 1, 2, 3, 4, 5, 6]);
  rollOffFirst(g);
  E.roll(g);
  const k = E.keep(g, [0, 1, 2, 3, 4, 5]);
  assert.equal(k.combo, 'straight');
  assert.equal(k.delta, 1500);
  assert.equal(k.hotDice, true);
  assert.equal(g.turn.diceRemaining, 6);
  assert.equal(g.turn.awaiting, 'roll');
  assert.deepEqual(g.turn.activated, {});
});

test('three pairs scores 1000', () => {
  const g = scriptedGame([6, 1, 2, 2, 4, 4, 6, 6]);
  rollOffFirst(g);
  E.roll(g);
  const k = E.keep(g, [0, 1, 2, 3, 4, 5]);
  assert.equal(k.combo, 'threePairs');
  assert.equal(k.delta, 1000);
});

test('partial keep from a straight breaks the combo', () => {
  const g = scriptedGame([6, 1, 1, 2, 3, 4, 5, 6]);
  rollOffFirst(g);
  E.roll(g);
  const k = E.keep(g, [0, 4]); // keep the 1 and 5 only
  assert.equal(k.combo, null);
  assert.equal(k.delta, 150);
});

test('six of a kind in one roll is an instant win', () => {
  const g = scriptedGame([6, 1, 5, 5, 5, 5, 5, 5]);
  rollOffFirst(g);
  const r = E.roll(g);
  assert.equal(r.instantWin, true);
  assert.equal(g.phase, 'over');
  assert.equal(g.winner, 0);
  assert.equal(g.winReason, 'sixOfAKind');
});

// --- bust / doubles / hot dice ----------------------------------------------

test('bust ends turn with zero and passes play', () => {
  const g = scriptedGame([6, 1, 2, 3, 4, 6, 6, 2]);
  rollOffFirst(g);
  const r = E.roll(g);
  assert.equal(r.bust, true);
  assert.equal(g.current, 1);
  assert.ok(g.turn); // next player's turn started
  assert.equal(g.players[0].score, 0);
});

test('doubles with 2 dice remaining triggers fresh six', () => {
  const g = scriptedGame([6, 1, 1, 1, 1, 5, 3, 3]);
  rollOffFirst(g);
  E.roll(g);
  const k = E.keep(g, [0, 1, 2, 3]); // three 1s + a 5 = 1050, leaves 3,3
  assert.equal(k.delta, 1050);
  assert.equal(k.doubles, true);
  assert.equal(g.turn.diceRemaining, 6);
  assert.equal(g.turn.turnTotal, 1050); // turn total kept
  assert.deepEqual(g.turn.activated, {}); // new roll set
});

test('keeping all dice is AND ROLLING', () => {
  const g = scriptedGame([6, 1, 1, 1, 1, 5, 5, 5]);
  rollOffFirst(g);
  E.roll(g);
  const k = E.keep(g, [0, 1, 2, 3, 4, 5]); // 1000 + 500
  assert.equal(k.delta, 1500);
  assert.equal(k.hotDice, true);
  assert.equal(g.turn.diceRemaining, 6);
});

// --- banking -----------------------------------------------------------------

test('cannot bank under 1000 (house rule)', () => {
  const g = scriptedGame([6, 1, 1, 5, 2, 3, 4, 6]);
  rollOffFirst(g);
  E.roll(g);
  E.keep(g, [0, 1]); // 150
  assert.equal(E.canBank(g), false);
  assert.throws(() => E.bank(g), /cannot bank/);
});

test('bank with 1000+ and 1 die remaining (house)', () => {
  const g = scriptedGame([6, 1, 1, 1, 1, 1, 1, 2]);
  rollOffFirst(g);
  E.roll(g);
  E.keep(g, [0, 1, 2, 3, 4]); // five 1s = 5000, 1 die left
  assert.equal(E.canBank(g), true);
  const res = E.bank(g);
  assert.equal(res.banked, 5000);
  assert.equal(g.players[0].score, 5000);
  assert.equal(g.players[0].hasEntered, true);
  assert.equal(g.current, 1);
});

test('classic rule banks with 2 dice remaining; house rule does not', () => {
  const seq = [6, 1, 1, 1, 1, 1, 2, 3];
  const gClassic = scriptedGame(seq, ['a', 'b'], { bankRule: 'classic' });
  rollOffFirst(gClassic);
  E.roll(gClassic);
  E.keep(gClassic, [0, 1, 2, 3]); // four 1s = 4000, 2 dice left
  assert.equal(E.canBank(gClassic), true);

  const gHouse = scriptedGame(seq, ['a', 'b'], { bankRule: 'house' });
  rollOffFirst(gHouse);
  E.roll(gHouse);
  E.keep(gHouse, [0, 1, 2, 3]); // four 1s = 4000, 2 dice left
  assert.equal(E.canBank(gHouse), false);
});

// --- final round ---------------------------------------------------------------

test('final round: leader holds without a 50+ overtake', () => {
  const g = scriptedGame([6, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2]);
  rollOffFirst(g);
  g.players[0].score = 11000;
  E.roll(g);
  E.keep(g, [0, 1, 2, 3, 4]); // +5000 -> 16000, triggers final round
  E.bank(g);
  assert.ok(g.finalRound);
  assert.equal(g.finalRound.leader, 0);
  assert.deepEqual(g.finalRound.remaining, [1]);
  assert.equal(g.current, 1);
  g.players[1].score = 11000;
  E.roll(g);
  E.keep(g, [0, 1, 2, 3, 4]); // +5000 -> 16000, not 50 over 16000
  E.bank(g);
  assert.equal(g.phase, 'over');
  assert.equal(g.winner, 0);
  assert.equal(g.winReason, 'finalRound');
});

test('final round: 50+ overtake takes the lead', () => {
  const g = scriptedGame([6, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2]);
  rollOffFirst(g);
  g.players[0].score = 11000;
  E.roll(g);
  E.keep(g, [0, 1, 2, 3, 4]);
  E.bank(g); // leader 0 at 16000
  g.players[1].score = 16000;
  E.roll(g);
  E.keep(g, [0, 1, 2, 3, 4]); // 21000 >= 16050 -> takes lead
  E.bank(g);
  assert.equal(g.phase, 'over');
  assert.equal(g.winner, 1);
});

// --- public state ---------------------------------------------------------------

test('publicState exposes a clean snapshot', () => {
  const g = scriptedGame([6, 1, 1, 5, 2, 3, 4, 6]);
  rollOffFirst(g);
  E.roll(g);
  const s = E.publicState(g);
  assert.equal(s.phase, 'play');
  assert.equal(s.current, 0);
  assert.equal(s.turn.awaiting, 'keep');
  assert.deepEqual(s.turn.rolled, [1, 5, 2, 3, 4, 6]);
  assert.equal(s.turn.canBank, false);
});
